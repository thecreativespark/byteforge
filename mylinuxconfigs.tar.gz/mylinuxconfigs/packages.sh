exec apt install xorg i3-wm feh compton firmware-linux firmware-linux-free firmware-linux-nonfree firmware-intel-sound firmware-iwlwifi firmware-realtek firmware-realtek-rtl8723cs-bt network-manager terminator git gcc g++ python3 curl ftp zip unzip ssh

exec sudo curl -fsSLo /usr/share/keyrings/brave-browser-archive-keyring.gpg https://brave-browser-apt-release.s3.brave.com/brave-browser-archive-keyring.gpg

exec echo "deb [signed-by=/usr/share/keyrings/brave-browser-archive-keyring.gpg] https://brave-browser-apt-release.s3.brave.com/ stable main"|sudo tee /etc/apt/sources.list.d/brave-browser-release.list

exec apt update

exec apt install brave-browser
